# Draw My Thing Cheat
You can use this tool from http://croutonix.github.io/dmtcheat/. The goal of this project is to provide an easy way to get pretty good at Draw my thing or similar games on Mineplex or The Hive.

# Contribute
You can contribute to this project mostly by adding words to the _wordlist-xxxx.txt_ files if you notice any are missing. Don't forget to separate each with a comma except after the last word. No need to add them in alphabetical order.